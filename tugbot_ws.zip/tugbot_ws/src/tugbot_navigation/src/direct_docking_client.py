#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from rclpy.action import ActionClient
from nav2_msgs.action import NavigateToPose
from geometry_msgs.msg import PoseStamped, Twist
from sensor_msgs.msg import LaserScan
import math
import time
import subprocess
import os
import yaml

class TugbotDockingClient(Node):
    def __init__(self):
        super().__init__('tugbot_docking_client')
        
        # Declare parameters for dock selection and coordinates
        self.declare_parameter('dock_name', 'home_dock')
        self.declare_parameter('charging_station_x', 21.4)
        self.declare_parameter('charging_station_y', -5.0)
        self.declare_parameter('charging_station_theta', 3.14159)
        self.declare_parameter('debug_skip_nav', False)
        
        # Create velocity publishers for multiple topics
        self.cmd_vel_pub = self.create_publisher(Twist, '/cmd_vel', 10)
        self.cmd_vel_nav_pub = self.create_publisher(Twist, '/cmd_vel_nav', 10)
        
        # Try to load from YAML file first
        dock_name = self.get_parameter('dock_name').value
        config_loaded = self.load_docking_config(dock_name)
        
        # Fall back to parameters if config file fails
        if not config_loaded:
            self.get_logger().info('Using parameters for docking coordinates')
            self.charging_station = {
                'x': self.get_parameter('charging_station_x').value,
                'y': self.get_parameter('charging_station_y').value,
                'theta': self.get_parameter('charging_station_theta').value
            }
            
            # Default values if not loading from config
            self.pre_dock_distance = 1.0  # meters
            self.approach_speed = 0.1  # Slow approach speed
            self.min_obstacle_distance = 0.09  # meters
            self.max_retries = 3
        
        # Subscribe to LiDAR data
        self.scan_sub = self.create_subscription(
            LaserScan, '/scan_omni', self.scan_callback, 10)
        
        # Navigation action client
        self.nav_client = ActionClient(self, NavigateToPose, 'navigate_to_pose')
        
        # State variables
        self.scan_data = None
        self.is_navigating = False
        self.is_final_approach = False
        self.obstacle_detected = False
        self.retry_count = 0
        self.approach_timer = None
        
        self.get_logger().info(f'Tugbot Docking Client initialized (Slow Speed Mode)')
        self.get_logger().info(f'Target charging station at: x={self.charging_station["x"]}, y={self.charging_station["y"]}, theta={self.charging_station["theta"]}')
    
    def load_docking_config(self, dock_name="home_dock"):
        """Load docking configuration from dedicated YAML file"""
        try:
            # Path to docking config file - adjust the path as needed
            config_path = os.path.join(
                os.path.dirname(os.path.abspath(__file__)), 
                "../config/adaptive_docking_params.yaml"
            )
            
            self.get_logger().info(f'Looking for docking config at: {config_path}')
            self.get_logger().info(f'Absolute path: {os.path.abspath(config_path)}')
            
            if not os.path.exists(config_path):
                self.get_logger().warn(f'Docking config file not found at: {config_path}')
                # Try alternate path
                config_path = "/home/mayank/tugbot_ws/src/tugbot_navigation/config/adaptive_docking_params.yaml"
                self.get_logger().info(f'Trying alternate path: {config_path}')
                if not os.path.exists(config_path):
                    self.get_logger().warn(f'Docking config still not found at: {config_path}')
                    return False
            
            with open(config_path, 'r') as file:
                config = yaml.safe_load(file)
            
            # Print the loaded config for debugging
            self.get_logger().info(f"Loaded YAML content with keys: {list(config.keys())}")
            
            # Check if requested dock exists
            if 'docking_stations' not in config or dock_name not in config['docking_stations']:
                self.get_logger().warn(f"Dock '{dock_name}' not found in configuration!")
                self.get_logger().info(f"Available docks: {list(config.get('docking_stations', {}).keys())}")
                return False
            
            # Get dock configuration
            dock_config = config['docking_stations'][dock_name]
            
            # Set parameters
            self.charging_station = {
                'x': dock_config['position']['x'],
                'y': dock_config['position']['y'],
                'theta': dock_config['position']['theta']
            }
            
            # Set approach parameters
            if 'approach' in dock_config:
                if 'offset_distance' in dock_config['approach']:
                    self.pre_dock_distance = dock_config['approach']['offset_distance']
                else:
                    self.pre_dock_distance = 1.0
                    
                if 'speed' in dock_config['approach']:
                    self.approach_speed = dock_config['approach']['speed']
                else:
                    self.approach_speed = 0.1
            else:
                self.pre_dock_distance = 1.0
                self.approach_speed = 0.1
            
            # Set thresholds
            if 'thresholds' in dock_config and 'docking' in dock_config['thresholds']:
                self.min_obstacle_distance = dock_config['thresholds']['docking']
            else:
                self.min_obstacle_distance = 0.09
            
            # Load global behavior settings
            if 'docking_behavior' in config and 'max_retries' in config['docking_behavior']:
                self.max_retries = config['docking_behavior']['max_retries']
            else:
                self.max_retries = 3
            
            self.get_logger().info(f"Loaded configuration for dock '{dock_name}'")
            self.get_logger().info(f"Position: x={self.charging_station['x']}, y={self.charging_station['y']}, theta={self.charging_station['theta']}")
            self.get_logger().info(f"Pre-dock distance: {self.pre_dock_distance}m, Approach speed: {self.approach_speed}m/s")
            
            return True
            
        except Exception as e:
            self.get_logger().error(f"Error loading docking configuration: {str(e)}")
            return False
    
    def send_velocity(self, linear_x, angular_z):
        """Send velocity commands using both ROS2 publisher and Gazebo command"""
        # Method 1: ROS2 publisher to standard topics
        msg = Twist()
        msg.linear.x = linear_x
        msg.angular.z = angular_z
        self.cmd_vel_pub.publish(msg)
        self.cmd_vel_nav_pub.publish(msg)
        
        # Method 2: Direct Gazebo command (the original method that worked for manual movement)
        try:
            cmd = f'gz topic -t /model/tugbot/cmd_vel -m gz.msgs.Twist -p "linear: {{x: {linear_x}}}, angular: {{z: {angular_z}}}"'
            subprocess.run(cmd, shell=True, check=False)
        except Exception as e:
            self.get_logger().error(f"Error sending Gazebo command: {str(e)}")
        
        self.get_logger().info(f"Published velocity using all methods: linear={linear_x}, angular={angular_z}")
    
    def scan_callback(self, msg):
        # Store scan data
        self.scan_data = msg
        
        # Check for obstacles in front
        if len(msg.ranges) > 0:
            # Front 90 degrees
            front_indices = range(len(msg.ranges) // 4, 3 * len(msg.ranges) // 4)
            front_ranges = [r for i, r in enumerate(msg.ranges) if i in front_indices and not math.isinf(r)]
            
            if front_ranges:
                min_front = min(front_ranges)
                self.obstacle_detected = min_front < self.min_obstacle_distance
                if self.obstacle_detected and self.is_final_approach:
                    self.get_logger().warn(f'Obstacle detected at {min_front:.2f}m during final approach!')
    
    def navigate_to_pre_dock(self):
        # Wait for action server
        self.get_logger().info('Waiting for navigation server...')
        self.nav_client.wait_for_server()
        
        # Calculate pre-docking position
        pre_dock_x = self.charging_station['x'] - self.pre_dock_distance * math.cos(self.charging_station['theta'])
        pre_dock_y = self.charging_station['y'] - self.pre_dock_distance * math.sin(self.charging_station['theta'])
        
        self.get_logger().info(f'Navigating to pre-docking position: ({pre_dock_x:.2f}, {pre_dock_y:.2f}) at reduced speed')
        
        # Create goal
        goal_msg = NavigateToPose.Goal()
        goal_pose = PoseStamped()
        goal_pose.header.frame_id = 'map'
        goal_pose.header.stamp = self.get_clock().now().to_msg()
        
        goal_pose.pose.position.x = pre_dock_x
        goal_pose.pose.position.y = pre_dock_y
        
        # Set orientation (pointing toward charging station)
        yaw = self.charging_station['theta']
        goal_pose.pose.orientation.w = math.cos(yaw / 2)
        goal_pose.pose.orientation.z = math.sin(yaw / 2)
        
        goal_msg.pose = goal_pose
        
        # Send goal
        self.is_navigating = True
        self.send_goal_future = self.nav_client.send_goal_async(goal_msg)
        self.send_goal_future.add_done_callback(self.goal_response_callback)
    
    def goal_response_callback(self, future):
        goal_handle = future.result()
        if not goal_handle.accepted:
            self.get_logger().error('Pre-docking goal rejected')
            self.is_navigating = False
            return
            
        self.get_logger().info('Pre-docking goal accepted')
        self.get_result_future = goal_handle.get_result_async()
        self.get_result_future.add_done_callback(self.get_result_callback)
    
    def get_result_callback(self, future):
        status = future.result().status
        if status == 4:  # StatusEnum.SUCCEEDED
            self.get_logger().info('Reached pre-docking position')
            self.start_final_approach()
        else:
            self.get_logger().error(f'Navigation failed with status: {status}')
            self.is_navigating = False
            
            # Retry if not at max retries
            if self.retry_count < self.max_retries:
                self.retry_count += 1
                self.get_logger().info(f'Retrying navigation (attempt {self.retry_count}/{self.max_retries})')
                time.sleep(2.0)  # Wait before retry
                self.navigate_to_pre_dock()
            else:
                self.get_logger().error('Maximum retry attempts reached')
    
    def start_final_approach(self):
        self.get_logger().info('Starting final approach to charging station at reduced speed')
        self.is_final_approach = True
        
        # Initialize approach timer
        self.approach_start_time = time.time()
        
        # Start a timer to continuously send velocity commands
        if self.approach_timer is None:
            self.approach_timer = self.create_timer(0.1, self.drive_and_monitor)
        
        self.get_logger().info(f'Moving forward at {self.approach_speed} m/s')
    
    def drive_and_monitor(self):
        """Send continuous velocity commands and monitor the approach"""
        if not self.is_final_approach:
            self.stop_robot()
            if self.approach_timer is not None:
                self.approach_timer.cancel()
                self.approach_timer = None
            return
            
        # Send drive command continuously using all methods
        self.send_velocity(self.approach_speed, 0.0)
        
        # If obstacle detected, stop
        if self.obstacle_detected:
            self.get_logger().warn('Obstacle detected during final approach!')
            self.stop_robot()
            self.is_final_approach = False
            if self.approach_timer is not None:
                self.approach_timer.cancel()
                self.approach_timer = None
            return
            
        # Check for timeout
        if time.time() - self.approach_start_time > 15.0:
            self.get_logger().info('Docking complete!')
            self.stop_robot()
            self.is_final_approach = False
            if self.approach_timer is not None:
                self.approach_timer.cancel()
                self.approach_timer = None
            
            # Simulate charging connection
            self.get_logger().info('Charging connection established')
    
    def stop_robot(self):
        """Stop the robot using all methods"""
        self.send_velocity(0.0, 0.0)
        self.get_logger().info('Robot stopped')
    
    def start_docking(self):
        self.get_logger().info('Starting docking sequence')
        self.retry_count = 0
        
        # Check for debug mode to skip navigation
        if self.get_parameter('debug_skip_nav').value:
            self.get_logger().info('DEBUG MODE: Skipping navigation, going straight to final approach')
            self.start_final_approach()
        else:
            self.navigate_to_pre_dock()

def main():
    rclpy.init()
    node = TugbotDockingClient()
    
    # Wait a moment for subscribers to connect
    time.sleep(2.0)
    
    # Start docking process
    node.start_docking()
    
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        node.get_logger().info('Docking interrupted')
        node.stop_robot()
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()