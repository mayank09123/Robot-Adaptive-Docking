import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess
from launch.conditions import IfCondition, UnlessCondition
from launch.substitutions import LaunchConfiguration, Command
from launch_ros.actions import Node
def generate_launch_description():
    # Launch configurations
    use_sim_time = LaunchConfiguration('use_sim_time')
    use_safety_bridge = LaunchConfiguration('use_safety_bridge')
    use_astar = LaunchConfiguration('use_astar')
    start_docking_gui = LaunchConfiguration('start_docking_gui')

    # Get directories
    tugbot_bringup_dir = get_package_share_directory('tugbot_bringup')
    tugbot_navigation_dir = get_package_share_directory('tugbot_navigation')

    # Robot description
    robot_description = Command([
        'xacro ', os.path.join(tugbot_bringup_dir, 'model', 'tugbot', 'model.urdf.xacro')
    ])

    # Launch arguments
    declare_use_sim_time_argument = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation/Gazebo clock')
        
    declare_use_safety_bridge_argument = DeclareLaunchArgument(
        'use_safety_bridge',
        default_value='true',
        description='Use the safety direct bridge for obstacle avoidance')
        
    declare_use_astar_argument = DeclareLaunchArgument(
        'use_astar',
        default_value='false',
        description='Use A* navigation for path planning')
        
    declare_start_docking_gui_argument = DeclareLaunchArgument(
        'start_docking_gui',
        default_value='false',
        description='Start the docking GUI interface')

    # Bridge between Gazebo and ROS 2
    bridge_node = Node(
        package='ros_gz_bridge',
        executable='parameter_bridge',
        name='parameter_bridge',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=[
            '/clock@rosgraph_msgs/msg/Clock[gz.msgs.Clock',
            '/model/tugbot/odometry@nav_msgs/msg/Odometry[gz.msgs.Odometry',
            '/model/tugbot/pose@tf2_msgs/msg/TFMessage[gz.msgs.Pose_V',
            '/world/world_demo/model/tugbot/link/scan_omni/sensor/scan_omni/scan@sensor_msgs/msg/LaserScan[gz.msgs.LaserScan',
          
          
            '/imu@sensor_msgs/msg/Imu[gz.msgs.IMU',
            '/joint_states@sensor_msgs/msg/JointState[gz.msgs.Model',
            '/cmd_vel@geometry_msgs/msg/Twist[gz.msgs.Twist'
        ],
        remappings=[
            ('/model/tugbot/odometry', '/odom'),
            ('/model/tugbot/pose', '/tf'),
            ('/imu', '/imu/data'),
            ('/world/world_demo/model/tugbot/link/scan_omni/sensor/scan_omni/scan', '/scan_omni')
        ]
    )

    # Static transforms
    static_tf_map_odom = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_map_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'map', 'odom']
    )
    static_odom_tf = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_map_odom',
        arguments=['0', '0', '0', '0', '0', '0', 'odom', 'base_link']
    )

    # Transform for all sensors
    static_tf_scan_omni = Node(
        package='tf2_ros',
        executable='static_transform_publisher',
        name='static_tf_pub_base_scan_omni',
        arguments=['0', '0.2', '0', '0', '0', '0', 'base_link', 'scan_omni']
    )
    
   
    

  
    # Robot state publisher
    robot_state_publisher = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'robot_description': robot_description}
        ]
    )

    # EKF config path
    ekf_config = os.path.join(tugbot_bringup_dir, 'config', 'ekf.yaml')

    robot_localization_node = Node(
        package='robot_localization',
        executable='ekf_node',
        name='ekf_filter_node',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            ekf_config
        ]
    )

    # SLAM Toolbox Node
    slam_toolbox_config = os.path.join(tugbot_bringup_dir, 'config', 'slam_toolbox.yaml')
    slam_toolbox_node = Node(
        package='slam_toolbox',
        executable='async_slam_toolbox_node',
        name='slam_toolbox',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            slam_toolbox_config
        ]
    )
    
    # Command velocity relay - only used when safety bridge is disabled
    cmd_vel_relay = Node(
        package='topic_tools',
        executable='relay',
        name='cmd_vel_relay',
        parameters=[{'use_sim_time': use_sim_time}],
        arguments=['/cmd_vel_nav', '/cmd_vel'],
        condition=UnlessCondition(use_safety_bridge)
    )
    
    # Safety bridge node - only used when safety bridge is enabled
    safety_bridge_node = Node(
        package='tugbot_navigation',
        executable='safety_direct_bridge.py',
        name='safety_direct_bridge',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'min_distance': 0.4},
            {'emergency_stop_distance': 0.25},
            {'linear_amp': 1.5},
            {'angular_amp': 1.2},
            {'max_linear': 1.0},
            {'max_angular': 1.0},
            {'min_linear': 0.2}
        ],
        condition=IfCondition(use_safety_bridge)
    )
    
    # A* navigator - only used when A* is enabled
    astar_navigator_node = Node(
        package='tugbot_navigation',
        executable='astar_navigator.py',
        name='astar_navigator',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'map_resolution': 0.05},
            {'robot_radius': 0.3},
            {'safety_margin': 0.4},
            {'max_linear_speed': 0.5},
            {'max_angular_speed': 0.8},
            {'goal_tolerance': 0.2},
            {'update_frequency': 5.0},
            {'visualization_enabled': True}
        ],
        condition=IfCondition(use_astar)
    )
    
    # Docking GUI - only used when docking GUI is enabled
    docking_gui_node = Node(
        package='tugbot_navigation',
        executable='docking_gui.py',
        name='docking_gui',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time}
        ],
        condition=IfCondition(start_docking_gui)
    )
    
    # Direct docking client
    direct_docking_client_node = Node(
        package='tugbot_navigation',
        executable='direct_docking_client.py',
        name='direct_docking_client',
        output='screen',
        parameters=[
            {'use_sim_time': use_sim_time},
            {'dock_position': [21.4, -5.0]},
            {'dock_orientation': 3.14159},
            {'approach_distance': 0.8},
            {'laser_threshold': 0.3},
            {'use_visual_markers': True},
            {'use_lidar': True}
        ],
        condition=IfCondition(start_docking_gui)
    )

    # Create the launch description
    ld = LaunchDescription()

    # Add launch arguments
    ld.add_action(declare_use_sim_time_argument)
    ld.add_action(declare_use_safety_bridge_argument)
    ld.add_action(declare_use_astar_argument)
    ld.add_action(declare_start_docking_gui_argument)
    
    # Add nodes
    ld.add_action(bridge_node)
    ld.add_action(static_tf_map_odom)
    ld.add_action(static_tf_scan_omni)
    ld.add_action(robot_state_publisher)
    ld.add_action(robot_localization_node)
    ld.add_action(slam_toolbox_node)
    ld.add_action(static_odom_tf)
    # Add conditional nodes
    ld.add_action(cmd_vel_relay)
    ld.add_action(safety_bridge_node)
    ld.add_action(astar_navigator_node)
    ld.add_action(docking_gui_node)
    ld.add_action(direct_docking_client_node)

    return ld