from launch import LaunchDescription
from launch.actions import ExecuteProcess, RegisterEventHandler, EmitEvent, DeclareLaunchArgument
from launch.event_handlers import OnProcessExit
from launch.events import Shutdown
from launch.substitutions import LaunchConfiguration, EnvironmentVariable
from launch_ros.actions import Node
import os

def generate_launch_description():
    # Get environment variables for charging station coordinates
    # These will be set by the GUI
    charging_station_x = LaunchConfiguration('charging_station_x', default=EnvironmentVariable('CHARGING_STATION_X', default_value='21.4'))
    charging_station_y = LaunchConfiguration('charging_station_y', default=EnvironmentVariable('CHARGING_STATION_Y', default_value='-5.0'))
    charging_station_theta = LaunchConfiguration('charging_station_theta', default=EnvironmentVariable('CHARGING_STATION_THETA', default_value='3.14159'))
    
    # Add new parameter for dock name
    dock_name = LaunchConfiguration('dock_name', default=EnvironmentVariable('DOCK_NAME', default_value='home_dock'))
    
    # Declare launch arguments
    declare_x = DeclareLaunchArgument(
        'charging_station_x',
        default_value=charging_station_x,
        description='X coordinate of the charging station'
    )
    
    declare_y = DeclareLaunchArgument(
        'charging_station_y',
        default_value=charging_station_y,
        description='Y coordinate of the charging station'
    )
    
    declare_theta = DeclareLaunchArgument(
        'charging_station_theta',
        default_value=charging_station_theta,
        description='Orientation (theta) of the charging station'
    )
    
    # Declare dock name argument
    declare_dock_name = DeclareLaunchArgument(
        'dock_name',
        default_value=dock_name,
        description='Name of the docking station from configuration file'
    )
    
    # Launch the navigation stack
    nav2_cmd = ExecuteProcess(
        cmd=['ros2', 'launch', 'nav2_bringup', 'bringup_launch.py', 
             'map:=/home/mayank/tugbot_ws/src/tugbot_navigation/maps/my_depot_map.yaml',
             'use_sim_time:=true'],
        output='screen'
    )
    
    # Launch RViz
    rviz_cmd = ExecuteProcess(
        cmd=['ros2', 'run', 'rviz2', 'rviz2', '-d', 
             '$(ros2 pkg prefix nav2_bringup)/share/nav2_bringup/rviz/nav2_default_view.rviz'],
        output='screen'
    )
    
    # Launch the velocity bridge
    velocity_bridge_node = Node(
        package='tugbot_navigation',
        executable='safety_direct_bridge.py',
        name='velocity_bridge',
        output='screen'
    )
    
    # Launch the docking client with parameters
    docking_client_node = Node(
        package='tugbot_navigation',
        executable='direct_docking_client.py',
        name='tugbot_docking_client',
        output='screen',
        parameters=[{
            'dock_name': dock_name,            # Added dock_name parameter
            'charging_station_x': charging_station_x,
            'charging_station_y': charging_station_y,
            'charging_station_theta': charging_station_theta
        }]
    )
    
    # Define shutdown behavior
    shutdown_on_exit = RegisterEventHandler(
        event_handler=OnProcessExit(
            target_action=nav2_cmd,
            on_exit=[EmitEvent(event=Shutdown())]
        )
    )
    
    return LaunchDescription([
        declare_x,
        declare_y,
        declare_theta,
        declare_dock_name,     # Added to the launch description
        nav2_cmd,
        rviz_cmd,
        velocity_bridge_node,
        docking_client_node,
        shutdown_on_exit
    ])