#!/usr/bin/env python3
import subprocess
import os

# Get the path to the adaptive docking client
script_path = os.path.expanduser("~/tugbot_ws/src/tugbot_navigation/src/adaptive_docking_client.py")

print("Starting adaptive docking...")
try:
    # Launch the script in a new process
    process = subprocess.Popen(["python3", script_path])
    print(f"Docking process started with PID: {process.pid}")
except Exception as e:
    print(f"Error starting docking: {e}")