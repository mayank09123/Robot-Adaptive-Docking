import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    map_dir = LaunchConfiguration('map_dir')
    params_file = LaunchConfiguration('params_file')

    tugbot_navigation_dir = get_package_share_directory('tugbot_navigation')
    nav2_bringup_dir = get_package_share_directory('nav2_bringup')

    # ✅ Use correct absolute paths directly
    default_map_path = '/home/mayank/tugbot_ws/src/tugbot_navigation/maps/my_depot_map.yaml'
    default_params_path = '/home/mayank/tugbot_ws/src/tugbot_navigation/config/nav2_params.yaml'

    declare_use_sim_time_cmd = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation (Gazebo) clock if true')

    declare_map_dir_cmd = DeclareLaunchArgument(
        'map_dir',
        default_value=default_map_path,
        description='Full path to map file to load')

    declare_params_file_cmd = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_path,
        description='Full path to the ROS2 parameters file')

    nav2_bringup_cmd = IncludeLaunchDescription(
        PythonLaunchDescriptionSource(os.path.join(nav2_bringup_dir, 'launch', 'bringup_launch.py')),
        launch_arguments={
            'map': map_dir,
            'use_sim_time': use_sim_time,
            'params_file': params_file
        }.items())

    # Optional battery monitor node
    battery_monitor_node = Node(
        package='tugbot_navigation',
        executable='charge_battery.py',
        name='battery_monitor',
        output='screen',
        parameters=[{'use_sim_time': use_sim_time}]
    )

    return LaunchDescription([
        declare_use_sim_time_cmd,
        declare_map_dir_cmd,
        declare_params_file_cmd,
        nav2_bringup_cmd,
        battery_monitor_node
    ])
