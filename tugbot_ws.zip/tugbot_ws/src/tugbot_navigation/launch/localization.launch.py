import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    map_file = LaunchConfiguration('map')
    params_file = LaunchConfiguration('params_file')
    
    tugbot_navigation_dir = get_package_share_directory('tugbot_navigation')
    
    default_map_path = os.path.join(
        tugbot_navigation_dir, 'maps', 'my_depot_map.yaml')
    
    default_params_file = os.path.join(
        tugbot_navigation_dir, 'config', 'mapper_params_localization.yaml')
    
    declare_use_sim_time_argument = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation/Gazebo clock')
    
    declare_map_cmd = DeclareLaunchArgument(
        'map',
        default_value=default_map_path,
        description='Full path to map yaml file to load')
    
    declare_params_file_cmd = DeclareLaunchArgument(
        'params_file',
        default_value=default_params_file,
        description='Full path to the localization parameters file')
    
    start_localization_cmd = Node(
        parameters=[
            params_file,
            {'use_sim_time': use_sim_time},
            {'map': map_file}
        ],
        package='slam_toolbox',
        executable='localization_slam_toolbox_node',
        name='slam_toolbox',
        output='screen')
    
    ld = LaunchDescription()
    
    ld.add_action(declare_use_sim_time_argument)
    ld.add_action(declare_map_cmd)
    ld.add_action(declare_params_file_cmd)
    ld.add_action(start_localization_cmd)
    
    return ld