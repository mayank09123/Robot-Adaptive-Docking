import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    
    tugbot_slam_dir = get_package_share_directory('tugbot_slam')
    rviz_config_file = os.path.join(tugbot_slam_dir, 'rviz', 'slam.rviz')
    
    declare_use_sim_time_argument = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation/Gazebo clock')
    
    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        arguments=['-d', rviz_config_file],
        parameters=[{'use_sim_time': use_sim_time}],
        output='screen')
    
    ld = LaunchDescription()
    
    ld.add_action(declare_use_sim_time_argument)
    ld.add_action(rviz_node)
    
    return ld