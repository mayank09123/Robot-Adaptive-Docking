#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist
import subprocess

class DirectBridge(Node):
    def __init__(self):
        super().__init__('direct_bridge')
        self.subscription = self.create_subscription(
            Twist, '/cmd_vel_nav', self.cmd_vel_callback, 10)
        print("Direct Bridge started - preserving direction with amplification")
        
    def cmd_vel_callback(self, msg):
        # Preserve direction but amplify magnitude
        linear_amp = 0.4
        angular_amp = 0.4
        
        # Apply amplification while preserving signs
        linear_x = msg.linear.x * linear_amp
        angular_z = msg.angular.z * angular_amp
        
        # Apply maximum speed limits
        max_linear = 0.3
        max_angular = 0.3
        
        linear_x = max(-max_linear, min(linear_x, max_linear))
        angular_z = max(-max_angular, min(angular_z, max_angular))
        
        # Send command to Gazebo with preserved direction
        cmd = f'gz topic -t /model/tugbot/cmd_vel -m gz.msgs.Twist -p "linear: {{x: {linear_x}}}, angular: {{z: {angular_z}}}"'
        print(f"Command: linear={linear_x}, angular={angular_z}")
        subprocess.run(cmd, shell=True)

def main():
    rclpy.init()
    bridge = DirectBridge()
    try:
        rclpy.spin(bridge)
    except KeyboardInterrupt:
        print("\nBridge stopped by user")
    bridge.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()