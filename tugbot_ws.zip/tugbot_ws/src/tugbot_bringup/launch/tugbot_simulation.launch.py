import os
from ament_index_python.packages import get_package_share_directory
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, IncludeLaunchDescription, ExecuteProcess, SetEnvironmentVariable
from launch.launch_description_sources import PythonLaunchDescriptionSource
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node

def generate_launch_description():
    use_sim_time = LaunchConfiguration('use_sim_time')
    
    tugbot_bringup_dir = get_package_share_directory('tugbot_bringup')
    
    # SDF file path - using absolute path
    model_path = os.path.join(tugbot_bringup_dir, 'model')
    world_file = os.path.join(model_path, 'worlds', 'world_demo.sdf')
    
    # Set Gazebo environment variable to find the models
    gazebo_resource_path = SetEnvironmentVariable(
        name='GZ_SIM_RESOURCE_PATH',
        value=[model_path, ':',
               os.path.join(model_path, 'tugbot'), ':',
               os.path.join(model_path, 'worlds')]
    )
    
    # Launch arguments
    declare_use_sim_time_argument = DeclareLaunchArgument(
        'use_sim_time',
        default_value='true',
        description='Use simulation/Gazebo clock')
    
    # Launch Gazebo simulation directly with ExecuteProcess
    gazebo = ExecuteProcess(
        cmd=['gz', 'sim', '-r', world_file],
        output='screen'
    )
    
    # Launch the bridge between Gazebo and ROS 2
    bridge = IncludeLaunchDescription(
        PythonLaunchDescriptionSource([
            os.path.join(tugbot_bringup_dir, 'launch', 'tugbot_bridge.launch.py')
        ]),
        launch_arguments={
            'use_sim_time': use_sim_time
        }.items()
    )
    
    # Create launch description
    ld = LaunchDescription()
    
    # Add actions to launch description
    ld.add_action(gazebo_resource_path)  # Add this line to set the environment variable
    ld.add_action(declare_use_sim_time_argument)
    ld.add_action(gazebo)
    ld.add_action(bridge)
    
    return ld